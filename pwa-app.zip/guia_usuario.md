# Guia do Usuário - PWA Meus Textos Favoritos

## Introdução

Bem-vindo ao **Meus Textos Favoritos**, um Progressive Web App (PWA) desenvolvido para permitir que você salve, organize e acesse seus textos favoritos de forma fácil e intuitiva. Este aplicativo funciona em qualquer dispositivo com navegador moderno e pode ser instalado na tela inicial do seu smartphone, tablet ou computador.

## Funcionalidades Principais

### 1. Gerenciamento de Textos Favoritos
- Adicione textos importantes com títulos personalizados
- Visualize todos os seus textos salvos em um só lugar
- Edite textos e títulos quando necessário
- Exclua textos que não são mais relevantes
- Compartilhe textos com outras pessoas

### 2. Organização por Categorias
- Crie categorias personalizadas para organizar seus textos
- Atribua textos a categorias específicas
- Visualize textos por categoria
- Edite ou exclua categorias conforme necessário

### 3. Busca Rápida
- Encontre rapidamente textos usando a barra de busca
- Pesquise por palavras-chave nos títulos ou conteúdos

### 4. Modo Escuro/Claro
- Alterne entre os temas claro e escuro conforme sua preferência
- Reduz o cansaço visual em ambientes com pouca luz

### 5. Funcionamento Offline
- Acesse seus textos mesmo sem conexão com a internet
- Todas as alterações são salvas localmente no seu dispositivo

## Como Usar

### Tela Inicial
A tela inicial do aplicativo é dividida em duas abas principais:
- **Favoritos**: Mostra todos os seus textos salvos
- **Categorias**: Mostra todas as categorias que você criou

### Adicionar um Novo Texto Favorito
1. Clique no botão "+" flutuante no canto inferior direito
2. Preencha o título do texto
3. Selecione uma categoria (opcional)
4. Digite ou cole o texto que deseja salvar
5. Clique em "Salvar"

### Visualizar um Texto Favorito
1. Na aba "Favoritos", clique no card do texto que deseja visualizar
2. O texto completo será exibido em uma janela modal
3. Use os botões na parte inferior para compartilhar, editar ou excluir o texto

### Criar uma Nova Categoria
1. Na aba "Categorias", clique em "Criar primeira categoria" (ou no botão "+" se já existirem categorias)
2. Digite o nome da categoria
3. Clique em "Salvar"

### Buscar Textos
1. Digite palavras-chave na barra de busca no topo da tela
2. Os resultados serão filtrados automaticamente enquanto você digita
3. Clique no "X" para limpar a busca

### Alternar Tema
- Clique no ícone de lua/sol no canto superior direito para alternar entre os temas claro e escuro

## Instalação na Tela Inicial

### Em Dispositivos Android
1. Abra o aplicativo no Chrome
2. Toque no menu (três pontos) no canto superior direito
3. Selecione "Adicionar à tela inicial" ou "Instalar aplicativo"
4. Confirme a instalação

### Em Dispositivos iOS (iPhone/iPad)
1. Abra o aplicativo no Safari
2. Toque no ícone de compartilhamento (retângulo com seta para cima)
3. Role para baixo e selecione "Adicionar à Tela de Início"
4. Confirme a instalação

### Em Computadores (Desktop)
1. Abra o aplicativo no Chrome, Edge ou outro navegador compatível
2. Clique no ícone de instalação na barra de endereço (geralmente um "+" ou ícone de computador)
3. Clique em "Instalar"

## Funcionamento Offline

Após a primeira visita ao aplicativo, os recursos essenciais são armazenados localmente no seu dispositivo. Isso significa que você pode:
- Acessar o aplicativo mesmo sem conexão com a internet
- Visualizar, adicionar, editar e excluir textos offline
- Todas as alterações feitas offline serão mantidas quando você voltar a ficar online

## Limitações Atuais

- Os dados são armazenados apenas no dispositivo atual (não há sincronização entre dispositivos)
- O espaço de armazenamento é limitado pelo navegador (geralmente suficiente para milhares de textos)
- Algumas funcionalidades avançadas podem não estar disponíveis em navegadores mais antigos

## Suporte e Feedback

Este é um protótipo inicial do aplicativo. Novas funcionalidades e melhorias serão implementadas com base no seu feedback.

## Próximas Atualizações Planejadas

- Sincronização entre dispositivos
- Backup em nuvem
- Editor de texto avançado com formatação
- Integração com serviços de armazenamento em nuvem
- Versão nativa para iOS e Android
