// Banco de dados usando IndexedDB
class FavoritesDB {
    constructor() {
        this.dbName = 'favoritesApp';
        this.dbVersion = 1;
        this.db = null;
        this.initDB();
    }

    // Inicializar o banco de dados
    async initDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onerror = (event) => {
                console.error('Erro ao abrir o banco de dados:', event.target.error);
                reject(event.target.error);
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                console.log('Banco de dados aberto com sucesso');
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                // Criar store para favoritos
                if (!db.objectStoreNames.contains('favorites')) {
                    const favoritesStore = db.createObjectStore('favorites', { keyPath: 'id', autoIncrement: true });
                    favoritesStore.createIndex('title', 'title', { unique: false });
                    favoritesStore.createIndex('categoryId', 'categoryId', { unique: false });
                    favoritesStore.createIndex('createdAt', 'createdAt', { unique: false });
                }

                // Criar store para categorias
                if (!db.objectStoreNames.contains('categories')) {
                    const categoriesStore = db.createObjectStore('categories', { keyPath: 'id', autoIncrement: true });
                    categoriesStore.createIndex('name', 'name', { unique: true });
                }

                console.log('Banco de dados criado/atualizado com sucesso');
            };
        });
    }

    // Garantir que o banco de dados está pronto
    async ensureDB() {
        if (!this.db) {
            await this.initDB();
        }
        return this.db;
    }

    // OPERAÇÕES DE FAVORITOS

    // Adicionar um novo favorito
    async addFavorite(favorite) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['favorites'], 'readwrite');
            const store = transaction.objectStore('favorites');
            
            // Adicionar timestamp
            favorite.createdAt = new Date().getTime();
            
            const request = store.add(favorite);
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao adicionar favorito:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Obter todos os favoritos
    async getAllFavorites() {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['favorites'], 'readonly');
            const store = transaction.objectStore('favorites');
            const request = store.getAll();
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao obter favoritos:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Obter favorito por ID
    async getFavoriteById(id) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['favorites'], 'readonly');
            const store = transaction.objectStore('favorites');
            const request = store.get(id);
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao obter favorito:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Obter favoritos por categoria
    async getFavoritesByCategory(categoryId) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['favorites'], 'readonly');
            const store = transaction.objectStore('favorites');
            const index = store.index('categoryId');
            const request = index.getAll(categoryId);
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao obter favoritos por categoria:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Atualizar um favorito
    async updateFavorite(favorite) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['favorites'], 'readwrite');
            const store = transaction.objectStore('favorites');
            
            // Manter o timestamp original de criação
            const request = store.get(favorite.id);
            
            request.onsuccess = (event) => {
                const existingFavorite = event.target.result;
                if (existingFavorite) {
                    favorite.createdAt = existingFavorite.createdAt;
                    
                    const updateRequest = store.put(favorite);
                    
                    updateRequest.onsuccess = (event) => {
                        resolve(event.target.result);
                    };
                    
                    updateRequest.onerror = (event) => {
                        console.error('Erro ao atualizar favorito:', event.target.error);
                        reject(event.target.error);
                    };
                } else {
                    reject(new Error('Favorito não encontrado'));
                }
            };
            
            request.onerror = (event) => {
                console.error('Erro ao obter favorito para atualização:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Excluir um favorito
    async deleteFavorite(id) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['favorites'], 'readwrite');
            const store = transaction.objectStore('favorites');
            const request = store.delete(id);
            
            request.onsuccess = (event) => {
                resolve(true);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao excluir favorito:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Buscar favoritos
    async searchFavorites(searchTerm) {
        const favorites = await this.getAllFavorites();
        
        if (!searchTerm || searchTerm.trim() === '') {
            return favorites;
        }
        
        searchTerm = searchTerm.toLowerCase().trim();
        
        return favorites.filter(favorite => {
            return (
                favorite.title.toLowerCase().includes(searchTerm) ||
                favorite.text.toLowerCase().includes(searchTerm)
            );
        });
    }

    // OPERAÇÕES DE CATEGORIAS

    // Adicionar uma nova categoria
    async addCategory(category) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['categories'], 'readwrite');
            const store = transaction.objectStore('categories');
            const request = store.add(category);
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao adicionar categoria:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Obter todas as categorias
    async getAllCategories() {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['categories'], 'readonly');
            const store = transaction.objectStore('categories');
            const request = store.getAll();
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao obter categorias:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Obter categoria por ID
    async getCategoryById(id) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['categories'], 'readonly');
            const store = transaction.objectStore('categories');
            const request = store.get(id);
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao obter categoria:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Atualizar uma categoria
    async updateCategory(category) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['categories'], 'readwrite');
            const store = transaction.objectStore('categories');
            const request = store.put(category);
            
            request.onsuccess = (event) => {
                resolve(event.target.result);
            };
            
            request.onerror = (event) => {
                console.error('Erro ao atualizar categoria:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // Excluir uma categoria
    async deleteCategory(id) {
        await this.ensureDB();
        
        return new Promise((resolve, reject) => {
            // Primeiro, verificar se há favoritos usando esta categoria
            this.getFavoritesByCategory(id).then(async (favorites) => {
                if (favorites.length > 0) {
                    // Atualizar favoritos para remover a referência à categoria
                    const updatePromises = favorites.map(favorite => {
                        favorite.categoryId = '';
                        return this.updateFavorite(favorite);
                    });
                    
                    await Promise.all(updatePromises);
                }
                
                // Agora excluir a categoria
                const transaction = this.db.transaction(['categories'], 'readwrite');
                const store = transaction.objectStore('categories');
                const request = store.delete(id);
                
                request.onsuccess = (event) => {
                    resolve(true);
                };
                
                request.onerror = (event) => {
                    console.error('Erro ao excluir categoria:', event.target.error);
                    reject(event.target.error);
                };
            }).catch(error => {
                console.error('Erro ao verificar favoritos da categoria:', error);
                reject(error);
            });
        });
    }

    // Contar favoritos por categoria
    async countFavoritesByCategory(categoryId) {
        const favorites = await this.getFavoritesByCategory(categoryId);
        return favorites.length;
    }
}

// Exportar a instância do banco de dados
const db = new FavoritesDB();
