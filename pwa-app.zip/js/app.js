// Elementos da interface
let themeToggle, searchInput, clearSearch, tabButtons, tabContents;
let addButton, addFirstFavorite, addFirstCategory, favoritesList, categoriesList;
let emptyFavorites, emptyCategories;

// Elementos dos modais
let modalOverlay, favoriteModal, categoryModal, viewModal;
let closeModal, closeCategoryModal, closeViewModal;
let cancelFavorite, cancelCategory, favoriteForm, categoryForm;
let modalTitle, categoryModalTitle;

// Variáveis de estado
let currentEditingFavoriteId = null;
let currentEditingCategoryId = null;
let currentViewingFavoriteId = null;

// Inicialização da aplicação
document.addEventListener('DOMContentLoaded', async () => {
    // Inicializar elementos DOM
    initDOMElements();
    
    // Verificar tema salvo
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.body.setAttribute('data-theme', savedTheme);
    updateThemeIcon();
    
    // Configurar event listeners
    setupEventListeners();
    
    // Carregar categorias no select
    await loadCategoriesIntoSelect();
    
    // Inicializar interface
    await updateUI();
});

// Inicializar elementos DOM
function initDOMElements() {
    // Elementos da interface
    themeToggle = document.getElementById('theme-toggle');
    searchInput = document.getElementById('search-input');
    clearSearch = document.getElementById('clear-search');
    tabButtons = document.querySelectorAll('.tab-button');
    tabContents = document.querySelectorAll('.tab-content');
    addButton = document.getElementById('add-button');
    addFirstFavorite = document.getElementById('add-first-favorite');
    addFirstCategory = document.getElementById('add-first-category');
    favoritesList = document.getElementById('favorites-list');
    categoriesList = document.getElementById('categories-list');
    emptyFavorites = document.getElementById('empty-favorites');
    emptyCategories = document.getElementById('empty-categories');

    // Elementos dos modais
    modalOverlay = document.getElementById('modal-overlay');
    favoriteModal = document.getElementById('favorite-modal');
    categoryModal = document.getElementById('category-modal');
    viewModal = document.getElementById('view-modal');
    closeModal = document.getElementById('close-modal');
    closeCategoryModal = document.getElementById('close-category-modal');
    closeViewModal = document.getElementById('close-view-modal');
    cancelFavorite = document.getElementById('cancel-favorite');
    cancelCategory = document.getElementById('cancel-category');
    favoriteForm = document.getElementById('favorite-form');
    categoryForm = document.getElementById('category-form');
    modalTitle = document.getElementById('modal-title');
    categoryModalTitle = document.getElementById('category-modal-title');
}

// Configuração de event listeners
function setupEventListeners() {
    // Alternar tema
    themeToggle.addEventListener('click', toggleTheme);
    
    // Busca
    searchInput.addEventListener('input', handleSearch);
    clearSearch.addEventListener('click', clearSearchInput);
    
    // Abas
    tabButtons.forEach(button => {
        button.addEventListener('click', () => switchTab(button.dataset.tab));
    });
    
    // Botões de adicionar
    addButton.addEventListener('click', showAddFavoriteModal);
    addFirstFavorite.addEventListener('click', showAddFavoriteModal);
    addFirstCategory.addEventListener('click', showAddCategoryModal);
    
    // Modais
    modalOverlay.addEventListener('click', closeAllModals);
    closeModal.addEventListener('click', () => closeModalByType('favorite'));
    closeCategoryModal.addEventListener('click', () => closeModalByType('category'));
    closeViewModal.addEventListener('click', () => closeModalByType('view'));
    cancelFavorite.addEventListener('click', () => closeModalByType('favorite'));
    cancelCategory.addEventListener('click', () => closeModalByType('category'));
    
    // Formulários
    favoriteForm.addEventListener('submit', handleFavoriteSubmit);
    categoryForm.addEventListener('submit', handleCategorySubmit);
    
    // Botões de ação no modal de visualização
    document.getElementById('share-favorite').addEventListener('click', shareFavorite);
    document.getElementById('edit-favorite').addEventListener('click', editCurrentFavorite);
    document.getElementById('delete-favorite').addEventListener('click', deleteCurrentFavorite);
}

// Funções de tema
function toggleTheme() {
    const currentTheme = document.body.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    document.body.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    updateThemeIcon();
}

function updateThemeIcon() {
    const currentTheme = document.body.getAttribute('data-theme');
    themeToggle.querySelector('.material-icons').textContent = 
        currentTheme === 'light' ? 'dark_mode' : 'light_mode';
}

// Funções de busca
async function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    
    // Mostrar/ocultar botão de limpar
    clearSearch.style.display = searchTerm ? 'flex' : 'none';
    
    // Buscar favoritos
    await updateFavoritesList(searchTerm);
}

function clearSearchInput() {
    searchInput.value = '';
    clearSearch.style.display = 'none';
    handleSearch();
}

// Funções de abas
function switchTab(tabId) {
    // Atualizar botões de abas
    tabButtons.forEach(button => {
        button.classList.toggle('active', button.dataset.tab === tabId);
    });
    
    // Atualizar conteúdo das abas
    tabContents.forEach(content => {
        if (content.id === `${tabId}-content`) {
            content.classList.add('active');
        } else {
            content.classList.remove('active');
        }
    });
}

// Funções de modal
function showAddFavoriteModal() {
    currentEditingFavoriteId = null;
    modalTitle.textContent = 'Adicionar Favorito';
    document.getElementById('favorite-title').value = '';
    document.getElementById('favorite-text').value = '';
    document.getElementById('favorite-category').selectedIndex = 0;
    
    openModal('favorite');
}

async function showEditFavoriteModal(favoriteId) {
    try {
        const favorite = await db.getFavoriteById(favoriteId);
        if (!favorite) {
            console.error('Favorito não encontrado:', favoriteId);
            return;
        }
        
        currentEditingFavoriteId = favoriteId;
        modalTitle.textContent = 'Editar Favorito';
        document.getElementById('favorite-title').value = favorite.title;
        document.getElementById('favorite-text').value = favorite.text;
        
        const categorySelect = document.getElementById('favorite-category');
        for (let i = 0; i < categorySelect.options.length; i++) {
            if (categorySelect.options[i].value == favorite.categoryId) {
                categorySelect.selectedIndex = i;
                break;
            }
        }
        
        openModal('favorite');
    } catch (error) {
        console.error('Erro ao carregar favorito para edição:', error);
    }
}

function showAddCategoryModal() {
    currentEditingCategoryId = null;
    categoryModalTitle.textContent = 'Adicionar Categoria';
    document.getElementById('category-name').value = '';
    
    openModal('category');
}

async function showEditCategoryModal(categoryId) {
    try {
        const category = await db.getCategoryById(categoryId);
        if (!category) {
            console.error('Categoria não encontrada:', categoryId);
            return;
        }
        
        currentEditingCategoryId = categoryId;
        categoryModalTitle.textContent = 'Editar Categoria';
        document.getElementById('category-name').value = category.name;
        
        openModal('category');
    } catch (error) {
        console.error('Erro ao carregar categoria para edição:', error);
    }
}

async function showViewModal(favoriteId) {
    try {
        const favorite = await db.getFavoriteById(favoriteId);
        if (!favorite) {
            console.error('Favorito não encontrado:', favoriteId);
            return;
        }
        
        currentViewingFavoriteId = favoriteId;
        document.getElementById('view-title').textContent = favorite.title;
        document.getElementById('view-text').textContent = favorite.text;
        
        // Mostrar categoria
        const categoryName = document.getElementById('view-category-name');
        if (favorite.categoryId) {
            try {
                const category = await db.getCategoryById(favorite.categoryId);
                categoryName.textContent = category ? category.name : 'Sem categoria';
            } catch (error) {
                console.error('Erro ao carregar categoria do favorito:', error);
                categoryName.textContent = 'Sem categoria';
            }
        } else {
            categoryName.textContent = 'Sem categoria';
        }
        
        openModal('view');
    } catch (error) {
        console.error('Erro ao carregar favorito para visualização:', error);
    }
}

function openModal(modalType) {
    modalOverlay.classList.add('active');
    
    if (modalType === 'favorite') {
        favoriteModal.classList.add('active');
    } else if (modalType === 'category') {
        categoryModal.classList.add('active');
    } else if (modalType === 'view') {
        viewModal.classList.add('active');
    }
}

function closeModalByType(modalType) {
    modalOverlay.classList.remove('active');
    
    if (modalType === 'favorite') {
        favoriteModal.classList.remove('active');
        currentEditingFavoriteId = null;
    } else if (modalType === 'category') {
        categoryModal.classList.remove('active');
        currentEditingCategoryId = null;
    } else if (modalType === 'view') {
        viewModal.classList.remove('active');
        currentViewingFavoriteId = null;
    }
}

function closeAllModals() {
    modalOverlay.classList.remove('active');
    favoriteModal.classList.remove('active');
    categoryModal.classList.remove('active');
    viewModal.classList.remove('active');
    currentEditingFavoriteId = null;
    currentEditingCategoryId = null;
    currentViewingFavoriteId = null;
}

// Funções de formulário
async function handleFavoriteSubmit(event) {
    event.preventDefault();
    
    const title = document.getElementById('favorite-title').value.trim();
    const text = document.getElementById('favorite-text').value.trim();
    const categorySelect = document.getElementById('favorite-category');
    const categoryId = categorySelect.value;
    
    if (!title || !text) {
        return;
    }
    
    try {
        if (currentEditingFavoriteId) {
            // Atualizar favorito existente
            await db.updateFavorite({
                id: currentEditingFavoriteId,
                title,
                text,
                categoryId
            });
        } else {
            // Adicionar novo favorito
            await db.addFavorite({
                title,
                text,
                categoryId
            });
        }
        
        closeModalByType('favorite');
        await updateUI();
    } catch (error) {
        console.error('Erro ao salvar favorito:', error);
    }
}

async function handleCategorySubmit(event) {
    event.preventDefault();
    
    const name = document.getElementById('category-name').value.trim();
    
    if (!name) {
        return;
    }
    
    try {
        if (currentEditingCategoryId) {
            // Atualizar categoria existente
            await db.updateCategory({
                id: currentEditingCategoryId,
                name
            });
        } else {
            // Adicionar nova categoria
            await db.addCategory({
                name
            });
        }
        
        closeModalByType('category');
        await loadCategoriesIntoSelect();
        await updateUI();
    } catch (error) {
        console.error('Erro ao salvar categoria:', error);
    }
}

// Funções de UI
async function updateUI() {
    await Promise.all([
        updateFavoritesList(),
        updateCategoriesList()
    ]);
}

async function updateFavoritesList(searchTerm) {
    try {
        // Obter favoritos (filtrados por busca, se houver)
        const favorites = searchTerm 
            ? await db.searchFavorites(searchTerm)
            : await db.getAllFavorites();
        
        // Verificar se há favoritos
        if (favorites.length === 0) {
            emptyFavorites.style.display = 'flex';
            favoritesList.style.display = 'none';
            return;
        }
        
        // Mostrar lista e ocultar estado vazio
        emptyFavorites.style.display = 'none';
        favoritesList.style.display = 'grid';
        
        // Limpar lista atual
        favoritesList.innerHTML = '';
        
        // Ordenar favoritos por data de criação (mais recentes primeiro)
        favorites.sort((a, b) => b.createdAt - a.createdAt);
        
        // Adicionar cada favorito à lista
        for (const favorite of favorites) {
            const card = document.createElement('div');
            card.className = 'favorite-card';
            card.dataset.id = favorite.id;
            
            // Obter nome da categoria, se houver
            let categoryName = 'Sem categoria';
            if (favorite.categoryId) {
                try {
                    const category = await db.getCategoryById(favorite.categoryId);
                    if (category) {
                        categoryName = category.name;
                    }
                } catch (error) {
                    console.error('Erro ao carregar categoria do favorito:', error);
                }
            }
            
            // Criar prévia do texto (primeiros 150 caracteres)
            const previewText = favorite.text.length > 150 
                ? favorite.text.substring(0, 150) + '...' 
                : favorite.text;
            
            card.innerHTML = `
                <h3 class="favorite-title">${escapeHTML(favorite.title)}</h3>
                <span class="favorite-category">${escapeHTML(categoryName)}</span>
                <p class="favorite-preview">${escapeHTML(previewText)}</p>
            `;
            
            // Adicionar evento de clique para visualizar
            card.addEventListener('click', () => showViewModal(favorite.id));
            
            favoritesList.appendChild(card);
        }
    } catch (error) {
        console.error('Erro ao atualizar lista de favoritos:', error);
    }
}

async function updateCategoriesList() {
    try {
        // Obter categorias
        const categories = await db.getAllCategories();
        
        // Verificar se há categorias
        if (categories.length === 0) {
            emptyCategories.style.display = 'flex';
            categoriesList.style.display = 'none';
            return;
        }
        
        // Mostrar lista e ocultar estado vazio
        emptyCategories.style.display = 'none';
        categoriesList.style.display = 'grid';
        
        // Limpar lista atual
        categoriesList.innerHTML = '';
        
        // Ordenar categorias por nome
        categories.sort((a, b) => a.name.localeCompare(b.name));
        
        // Adicionar cada categoria à lista
        for (const category of categories) {
            const card = document.createElement('div');
            card.className = 'category-card';
            card.dataset.id = category.id;
            
            // Contar favoritos nesta categoria
            const count = await db.countFavoritesByCategory(category.id);
            
            card.innerHTML = `
                <span class="material-icons category-icon">folder</span>
                <h3 class="category-name">${escapeHTML(category.name)}</h3>
                <p class="category-count">${count} favorito${count !== 1 ? 's' : ''}</p>
            `;
            
            // Adicionar evento de clique para editar
            card.addEventListener('click', () => showEditCategoryModal(category.id));
            
            categoriesList.appendChild(card);
        }
    } catch (error) {
        console.error('Erro ao atualizar lista de categorias:', error);
    }
}

async function loadCategoriesIntoSelect() {
    try {
        const categorySelect = document.getElementById('favorite-category');
        
        // Manter a opção "Sem categoria"
        categorySelect.innerHTML = '<option value="">Sem categoria</option>';
        
        // Obter categorias
        const categories = await db.getAllCategories();
        
        // Ordenar categorias por nome
        categories.sort((a, b) => a.name.localeCompare(b.name));
        
        // Adicionar cada categoria ao select
        for (const category of categories) {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            categorySelect.appendChild(option);
        }
    } catch (error) {
        console.error('Erro ao carregar categorias no select:', error);
    }
}

// Funções de ação
async function editCurrentFavorite() {
    if (currentViewingFavoriteId) {
        closeModalByType('view');
        await showEditFavoriteModal(currentViewingFavoriteId);
    }
}

async function deleteCurrentFavorite() {
    if (currentViewingFavoriteId) {
        if (confirm('Tem certeza que deseja excluir este favorito?')) {
            try {
                await db.deleteFavorite(currentViewingFavoriteId);
                closeModalByType('view');
                await updateUI();
            } catch (error) {
                console.error('Erro ao excluir favorito:', error);
            }
        }
    }
}

async function shareFavorite() {
    if (currentViewingFavoriteId) {
        try {
            const favorite = await db.getFavoriteById(currentViewingFavoriteId);
            if (!favorite) {
                return;
            }
            
            // Usar a API Web Share se disponível
            if (navigator.share) {
                await navigator.share({
                    title: favorite.title,
                    text: favorite.text
                });
            } else {
                // Fallback: copiar para a área de transferência
                const text = `${favorite.title}\n\n${favorite.text}`;
                await navigator.clipboard.writeText(text);
                alert('Texto copiado para a área de transferência!');
            }
        } catch (error) {
            console.error('Erro ao compartilhar favorito:', error);
        }
    }
}

// Utilitários
function escapeHTML(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
